import execute from '../src/js/execute';

describe('execute.js', () => {
    var e = {
        execute
    };

    delete e.execute;
});
